package com.jdbc;

import java.sql.*;

public class Jdbc {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conObj = DriverManager.getConnection("jdbc:mysql://localhost:3306/abmsschool","root", "Vignesh@1999");
			if(conObj!=null)
				System.out.println("Db Connected Successfully");
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}



}
