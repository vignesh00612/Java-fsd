package phase1AssistedPractice;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class PracticeProject17 {
	public static void main(String[] args) {

		String filename = "E:\\example.txt";

		// Create a file
		createFile(filename);

		// Write content to the file
		writeFile(filename, "Hello, World!");

		// Read content from the file
		String content = readFile(filename);
		System.out.println("Content read from file: " + content);

		// Update content in the file
		updateFile(filename, "Updated content.");

		// Read updated content from the file
		content = readFile(filename);
		System.out.println("Updated content read from file: " + content);

		// Delete the file
		deleteFile(filename);
	}

	// Method to create a file
	public static void createFile(String filename) {
		try {
			File file = new File(filename);
			if (file.createNewFile()) {
				System.out.println("File created: " + filename);
			} else {
				System.out.println("File already exists.");
			}
		} catch (IOException e) {
			System.out.println("An error occurred while creating the file: " + e.getMessage());
		}
	}

	// Method to write content to a file
	public static void writeFile(String filename, String content) {
		try {
			FileWriter writer = new FileWriter(filename);
			writer.write(content);
			writer.close();
			System.out.println("Content written to file.");
		} catch (IOException e) {
			System.out.println("An error occurred while writing to the file: " + e.getMessage());
		}
	}

	// Method to read content from a file
	public static String readFile(String filename) {
		StringBuilder content = new StringBuilder();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(filename));
			String line;
			while ((line = reader.readLine()) != null) {
				content.append(line);
			}
			reader.close();
		} catch (IOException e) {
			System.out.println("An error occurred while reading the file: " + e.getMessage());
		}
		return content.toString();
	}

	// Method to update content in a file
	public static void updateFile(String filename, String newContent) {
		try {
			FileWriter writer = new FileWriter(filename);
			writer.write(newContent);
			writer.close();
			System.out.println("Content updated in file.");
		} catch (IOException e) {
			System.out.println("An error occurred while updating the file: " + e.getMessage());
		}
	}

	// Method to delete a file
	public static void deleteFile(String filename) {
		File file = new File(filename);
		if (file.delete()) {
			System.out.println("File deleted: " + filename);
		} else {
			System.out.println("Failed to delete the file.");
		}
	}

}
