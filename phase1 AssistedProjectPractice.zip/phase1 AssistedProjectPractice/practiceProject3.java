package phase1AssistedPractice;

public class practiceProject3 {

	// Method with no return type and no parameters
	public static void greet() {
		System.out.println("Hello, welcome");
	}

	// Method with no return type and parameters
	public static void greetWithName(String name) {
		System.out.println("Hello, " + name + "! Welcome ");
	}

	// Method with return type and parameters
	public static int add(int a, int b) {
		return a + b;
	}

	public static void main(String[] args) {
		// Calling methods using different ways
		// 1. Calling method with no return type and no parameters
		greet();

		// 2. Calling method with no return type and parameters
		String userName = "John";
		greetWithName(userName);

		// 3. Calling method with return type and parameters
		int result = add(5, 4);
		System.out.println("Addition result: " + result);

		// 4. Storing method result in a variable and then printing
		int sum = add(10, 20);
		System.out.println("Sum: " + sum);

		// 5. Calling method inside another method call
		System.out.println("Sum of 5 and 4: " + add(5, 4));

		// 6. Using method result directly in an expression
		int product = add(2, 3) * 4;
		System.out.println("Product: " + product);
	}
}
