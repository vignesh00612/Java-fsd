package phase1AssistedPractice;

public class PracticeProject12 {
	public static void main(String[] args) {
		// Sleep demo
		System.out.println("Sleep demo:");
		sleepDemo();

		// Wait demo
		System.out.println("\nWait demo:");
		waitDemo();
	}

	// Method to demonstrate the sleep() method
	public static void sleepDemo() {
		try {
			System.out.println("Before sleep");
			Thread.sleep(2000); // Sleep for 2 seconds
			System.out.println("After sleep");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// Method to demonstrate the wait() method
	public static void waitDemo() {
		final Object lock = new Object(); // Object used for synchronization

		Thread thread1 = new Thread(() -> {
			synchronized (lock) {
				System.out.println("Thread 1: Before wait");
				try {
					lock.wait(); // Wait indefinitely until notified
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("Thread 1: After wait");
			}
		});

		Thread thread2 = new Thread(() -> {
			synchronized (lock) {
				System.out.println("Thread 2: Before notify");
				lock.notify(); // Notify the waiting thread
				System.out.println("Thread 2: After notify");
			}
		});

		thread1.start();
		thread2.start();
	}

}
