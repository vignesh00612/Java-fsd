package phase1AssistedPractice;

import java.util.Scanner;
import java.util.Stack;

public class PracticeProject27 {

	public static void main(String[] args) {
		Stack<Integer> stack = new Stack<>();

		// Insert elements into the stack
		System.out.println("Inserting elements into the stack:");
		stack.push(10);
		stack.push(20);
		stack.push(30);
		stack.push(40);
		stack.push(50);

		// Display the stack
		System.out.println("Stack elements: " + stack);

		// Remove elements from the stack
		System.out.println("\nRemoving elements from the stack:");
		while (!stack.isEmpty()) {
			int removedElement = stack.pop();
			System.out.println("Popped element: " + removedElement);
		}

		// Check if the stack is empty after removal
		if (stack.isEmpty()) {
			System.out.println("\nThe stack is empty now.");
		} else {
			System.out.println("\nThe stack is not empty.");
		}
	}
}
