package phase1AssistedPractice;

public class practiceProject9 {

	public static void main(String[] args) {
		
		        // Declaration and initialization of an array
		        int[] numbers = {1, 2, 3, 4, 5};

		        // Accessing elements of the array
		        System.out.println("Elements of the array:");
		        for (int i = 0; i < numbers.length; i++) {
		            System.out.print(numbers[i] + " ");
		        }
		        System.out.println(); // Print a newline after displaying elements

		        // Modifying an element of the array
		        numbers[2] = 10;

		        // Accessing and printing the modified element
		        System.out.println("Modified element at index 2: " + numbers[2]);

		        // Finding the sum of all elements in the array
		        int sum = 0;
		        for (int i = 0; i < numbers.length; i++) {
		            sum += numbers[i];
		        }
		        System.out.println("Sum of all elements: " + sum);

		        // Initializing an array with a specific size
		        int[] newArray = new int[3];
		        newArray[0] = 100;
		        newArray[1] = 200;
		        newArray[2] = 300;

		        // Displaying elements of the new array
		        System.out.println("Elements of the new array:");
		        for (int i = 0; i < newArray.length; i++) {
		            System.out.print(newArray[i] + " ");
		        }
		        System.out.println(); // Print a newline after displaying elements
		    }
		

		// TODO Auto-generated method stub

	}


