

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Servlet implementation class FilterServlet1
 */
@WebServlet("/FilterServlet1")
public class FilterServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FilterServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // For demonstration purposes, check if username and password are valid
        if ("admin".equals(username) && "admin".equals(password)) {
            // Create a session
            HttpSession session = request.getSession(true);
            session.setAttribute("username", username);

            // Redirect to welcome page
            response.sendRedirect(request.getContextPath() + "/Filter2.html");
        } else {
            // Redirect back to login page
            response.sendRedirect(request.getContextPath() + "/Filter1.html");
        }
    }
}