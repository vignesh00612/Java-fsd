package phase1AssistedPractice;

public class practiceProject1 {

	public static void main(String[] args) {
		// Implicit type casting
		System.out.println("Implicit casting");

		char b = 'B';
		System.out.println("Value of b is :" + b);

		int c = b;
		System.out.println("Value of c is :" + c);

		float d = b;
		System.out.println("Value of d is :" + d);

		long e = b;
		System.out.println("Value of e is :" + e);

		double f = b;
		System.out.println("Value of f is :" + f);

		System.out.println("\n");

		// Explicit type casting
		System.out.println("Explicit casting");
		double y = 55.5;
		int z = (int) y;
		System.out.println("Value of y is :" + y);
		System.out.println("Value of z is :" + z);

	}

}

