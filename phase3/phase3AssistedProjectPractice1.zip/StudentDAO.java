package pracprj;

import java.util.List;

public interface StudentDAO {
	void save(Student student);
    List<Student> getAllStudents();

}
