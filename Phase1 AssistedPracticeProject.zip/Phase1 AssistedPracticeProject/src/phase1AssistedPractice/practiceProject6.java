package phase1AssistedPractice;

import java.util.*;

public class practiceProject6 {

	public static void main(String[] args) {

		// HashMap
		Map<String, Integer> hashMap = new HashMap<>();
		hashMap.put("One", 1);
		hashMap.put("Two", 2);
		hashMap.put("Three", 3);
		System.out.println("HashMap: " + hashMap);

		// TreeMap
		Map<String, Integer> treeMap = new TreeMap<>();
		treeMap.put("Red", 1);
		treeMap.put("Green", 2);
		treeMap.put("Blue", 3);
		System.out.println("TreeMap: " + treeMap);

		// LinkedHashMap
		Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
		linkedHashMap.put("Monday", 1);
		linkedHashMap.put("Tuesday", 2);
		linkedHashMap.put("Wednesday", 3);
		System.out.println("LinkedHashMap: " + linkedHashMap);

		// Hashtable
		Map<String, Integer> hashtable = new Hashtable<>();
		hashtable.put("Apple", 1);
		hashtable.put("Banana", 2);
		hashtable.put("Orange", 3);
		System.out.println("Hashtable: " + hashtable);
	}

}
