package phase1AssistedPractice;

class Student {
	String name;
	int age;

	// Default Constructor
	public Student() {
		System.out.println("Default Constructor called");
		name = "John";
		age = 20;
	}

	// Parameterized Constructor
	public Student(String n, int a) {
		System.out.println("Parameterized Constructor called");
		name = n;
		age = a;
	}

	// Copy Constructor
	public Student(Student s) {
		System.out.println("Copy Constructor called");
		name = s.name;
		age = s.age;
	}

	// Display method to print student details
	public void display() {
		System.out.println("Name: " + name + ", Age: " + age);
	}
}

public class practiceProject4 {
	public static void main(String[] args) {
		// Creating objects using different types of constructors
		Student student1 = new Student(); // Default Constructor
		Student student2 = new Student("Alice", 22); // Parameterized Constructor
		Student student3 = new Student(student2); // Copy Constructor

		// Displaying student details
		System.out.println("Student 1:");
		student1.display();
		System.out.println("Student 2:");
		student2.display();
		System.out.println("Student 3:");
		student3.display();
	}
}
