package com.jdbc;

import java.sql.*;
import java.util.Scanner;

class Database
{
	private Connection con;

    public Database() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/abmsschool", "root", "Vignesh@1999");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertEmployee(int employee_id,String employee_name, double salary) {
        try {
            CallableStatement callableStatement = con.prepareCall("{call InsertEmployee(?, ?, ?)}");
            callableStatement.setInt(1, employee_id);
            callableStatement.setString(2, employee_name);
            callableStatement.setDouble(3, salary);
            callableStatement.execute();
            System.out.println("Employee inserted successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void closeConnection() {
        try {
            if (con != null) {
                con.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}

public class Jdbc4 {
	public static void main(String[] args) {
		Database dbop = new Database();
		
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter employee Id:");
        int employee_id = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter employee name:");
        String employee_name = sc.nextLine();

        System.out.println("Enter employee salary:");
        double salary = Double.parseDouble(sc.nextLine());

        dbop.insertEmployee(employee_id, employee_name, salary);

        dbop.closeConnection();
        sc.close();
	}

}
	


	