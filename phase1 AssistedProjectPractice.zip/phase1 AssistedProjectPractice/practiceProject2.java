package phase1AssistedPractice;
//Define a class with different access modifiers
class MyClass {
 // Private variable accessible only within this class
 int privateVar = 20;

 // Default variable accessible within the same package
 int defaultVar = 60;

 // Protected variable accessible within the same package and subclasses
 protected int protectedVar = 80;

 // Public variable accessible everywhere
 public int publicVar = 56;

 // Private method accessible only within this class
 private void privateMethod() {
     System.out.println("Private method called");
 }

 // Default method accessible within the same package
 void defaultMethod() {
     System.out.println("Default method called");
 }

 // Protected method accessible within the same package and subclasses
 protected void protectedMethod() {
     System.out.println("Protected method called");
 }

 // Public method accessible everywhere
 public void publicMethod() {
     System.out.println("Public method called");
 }
}

//Main class to test access modifiers

public class practiceProject2 {

 public static void main(String[] args) {
     // Create an object of MyClass
     MyClass obj = new MyClass();

     // Accessing variables and methods from the same class
     System.out.println("Private variable: " + obj.privateVar); // Error: privateVar has private access in MyClass
     System.out.println("Default variable: " + obj.defaultVar);
     System.out.println("Protected variable: " + obj.protectedVar);
     System.out.println("Public variable: " + obj.publicVar);

     // Accessing methods from the same class
     // obj.privateMethod(); // Error: privateMethod() has private access in MyClass
     obj.defaultMethod();
     obj.protectedMethod();
     obj.publicMethod();
 }


	}


