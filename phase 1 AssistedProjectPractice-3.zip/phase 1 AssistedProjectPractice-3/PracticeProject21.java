package phase1AssistedPractice;

import java.util.*;

public class PracticeProject21 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		// Input the size of the list
		System.out.print("Enter the size of the list: ");
		int size = scanner.nextInt();

		// Input the elements of the list
		System.out.println("Enter the elements of the list:");
		List<Integer> list = new ArrayList<>();
		for (int i = 0; i < size; i++) {
			list.add(scanner.nextInt());
		}

		// Find the fourth smallest element
		int fourthSmallest = findFourthSmallest(list);

		// Output the result
		if (fourthSmallest == Integer.MAX_VALUE) {
			System.out.println("There are less than four distinct elements in the list.");
		} else {
			System.out.println("The fourth smallest element in the list is: " + fourthSmallest);
		}
	}

	public static int findFourthSmallest(List<Integer> list) {
		TreeSet<Integer> uniqueElements = new TreeSet<>(list);
		if (uniqueElements.size() < 4) {
			return Integer.MAX_VALUE; // Less than four distinct elements
		}

		Iterator<Integer> iterator = uniqueElements.iterator();
		int fourthSmallest = 0;
		for (int i = 0; i < 4; i++) {
			fourthSmallest = iterator.next();
		}
		return fourthSmallest;
	}

}
