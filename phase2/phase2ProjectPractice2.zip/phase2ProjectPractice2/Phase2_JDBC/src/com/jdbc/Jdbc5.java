package com.jdbc;

import java.sql.*;

public class Jdbc5 {
	// JDBC URL, username, and password of MySQL server
    private static final String URL = "jdbc:mysql://localhost:3306/";
    private static final String USER = "root";
    private static final String PASSWORD = "Vignesh@1999";

    public static void main(String[] args) {
        createDatabase("test");
        selectDatabase("test"); 
        dropDatabase("test");  
    }

    // Method to create a new database
    public static void createDatabase(String dbName) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement statement = connection.createStatement()) {
            // SQL statement for creating a new database
            String sql = "CREATE DATABASE " + dbName;
            // Execute the SQL statement
            statement.executeUpdate(sql);
            System.out.println("Database '" + dbName + "' created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to select a database
    public static void selectDatabase(String dbName) {
        try (Connection connection = DriverManager.getConnection(URL + dbName, USER, PASSWORD)) {
            System.out.println("Connected to database '" + dbName + "'.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to drop a database
    public static void dropDatabase(String dbName) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement statement = connection.createStatement()) {
            // SQL statement for dropping the database
            String sql = "DROP DATABASE IF EXISTS " + dbName;
            // Execute the SQL statement
            statement.executeUpdate(sql);
            System.out.println("Database '" + dbName + "' dropped successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

