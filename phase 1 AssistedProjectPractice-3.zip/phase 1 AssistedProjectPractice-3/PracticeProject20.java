package phase1AssistedPractice;

import java.util.Scanner;

public class PracticeProject20 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter the size of the array: ");
		int size = scanner.nextInt();

		int[] array = new int[size];
		System.out.println("Enter the elements of the array:");
		for (int i = 0; i < size; i++) {
			array[i] = scanner.nextInt();
		}

		System.out.println("Original Array: ");
		printArray(array);

		rightRotate(array, 5);

		System.out.println("Array after right rotation by 5 steps: ");
		printArray(array);
	}

	public static void rightRotate(int[] arr, int steps) {
		int length = arr.length;
		steps = steps % length; // Handling cases where steps > length of array

		reverseArray(arr, 0, length - 1); // Reverse the entire array
		reverseArray(arr, 0, steps - 1); // Reverse the first 'steps' elements
		reverseArray(arr, steps, length - 1); // Reverse the remaining elements
	}

	public static void reverseArray(int[] arr, int start, int end) {
		while (start < end) {
			int temp = arr[start];
			arr[start] = arr[end];
			arr[end] = temp;
			start++;
			end--;
		}
	}

	public static void printArray(int[] arr) {
		for (int num : arr) {
			System.out.print(num + " ");
		}
		System.out.println();
	}

}
