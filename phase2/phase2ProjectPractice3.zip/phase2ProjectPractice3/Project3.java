package test;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import Hibernate.Person;
import jakarta.persistence.TypedQuery;

public class Project3 
{
	public static void main(String[] args)
	{
		Person p=new Person();
		p.setId(5);
		p.setPhone("98547614235");
		p.setPname("Deepu");
		p.setEmail("gan@gmail.com");
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction trans = session.beginTransaction();
		session.persist(p);
		trans.commit();
		System.out.println("Person Details are Added....");
		
		
	}

}
