package phase1AssistedPractice;

import java.util.*;

public class practiceProject5 {

	public static void main(String[] args) {

		// List
		List<String> list = new ArrayList<>();
		list.add("Apple");
		list.add("Banana");
		list.add("Orange");
		System.out.println("List:");
		System.out.println(list);

		// Set
		Set<Integer> set = new HashSet<>();
		set.add(10);
		set.add(20);
		set.add(30);
		System.out.println("\nSet:");
		System.out.println(set);

		// Queue
		Queue<String> queue = new LinkedList<>();
		queue.add("One");
		queue.add("Two");
		queue.add("Three");
		System.out.println("\nQueue:");
		System.out.println(queue);

		// Map
		Map<String, Integer> map = new HashMap<>();
		map.put("One", 1);
		map.put("Two", 2);
		map.put("Three", 3);
		System.out.println("\nMap:");
		System.out.println(map);

		// Iterate over collection elements
		System.out.println("\nIterating over List:");
		for (String item : list) {
			System.out.println(item);
		}

		System.out.println("\nIterating over Set:");
		for (int item : set) {
			System.out.println(item);
		}

		System.out.println("\nIterating over Queue:");
		for (String item : queue) {
			System.out.println(item);
		}

		System.out.println("\nIterating over Map:");
		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			System.out.println(entry.getKey() + ": " + entry.getValue());
		}
	}

}
