package phase1AssistedPractice;

import java.util.Scanner;

class ListNode {
	int val;
	ListNode next;

	ListNode(int val) {
		this.val = val;
		this.next = null;
	}
}

public class PracticeProject24 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		// Create a sample linked list: 1 -> 2 -> 3 -> 4 -> 5 -> null
		ListNode head = new ListNode(1);
		head.next = new ListNode(2);
		head.next.next = new ListNode(3);
		head.next.next.next = new ListNode(4);
		head.next.next.next.next = new ListNode(5);

		// Print the original linked list
		System.out.println("Original linked list:");
		printLinkedList(head);

		// Input the key to delete
		System.out.print("\nEnter the key to delete: ");
		int key = scanner.nextInt();

		// Delete the first occurrence of the key
		head = deleteFirstOccurrence(head, key);

		// Print the modified linked list
		System.out.println("\nLinked list after deleting first occurrence of " + key + ":");
		printLinkedList(head);
	}

	public static ListNode deleteFirstOccurrence(ListNode head, int key) {
		ListNode dummy = new ListNode(0);
		dummy.next = head;

		ListNode prev = dummy;
		ListNode curr = head;

		while (curr != null) {
			if (curr.val == key) {
				prev.next = curr.next;
				break;
			}
			prev = curr;
			curr = curr.next;
		}

		return dummy.next;
	}

	public static void printLinkedList(ListNode head) {
		ListNode curr = head;
		while (curr != null) {
			System.out.print(curr.val + " -> ");
			curr = curr.next;
		}
		System.out.println("null");
	}
}
