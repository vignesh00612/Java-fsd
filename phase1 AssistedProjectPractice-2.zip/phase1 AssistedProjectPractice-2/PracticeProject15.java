package phase1AssistedPractice;

class CustomException extends Exception {
	public CustomException(String message) {
		super(message);
	}
}

public class PracticeProject15 {

	public static void main(String[] args) {
		try {
			// Using throws to declare exception
			methodWithThrows();

			// Using throw to throw an exception
			methodWithThrow();

			// Finally block to ensure cleanup
		} catch (CustomException e) {
			System.out.println("Caught custom exception: " + e.getMessage());
		} finally {
			System.out.println("Finally block executed.");
		}
	}

	// Method that throws an exception
	public static void methodWithThrows() throws CustomException {
		throw new CustomException("Exception thrown using throws keyword");
	}

	// Method that throws an exception explicitly
	public static void methodWithThrow() throws CustomException {
		throw new CustomException("Exception thrown using throw keyword");
	}

	// TODO Auto-generated method stub

}
