package phase1AssistedPractice;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class PracticeProject28 {

	public static void main(String[] args) {
		Queue<Integer> queue = new LinkedList<>();

		// Insert elements into the queue
		System.out.println("Enqueuing elements into the queue:");
		queue.add(10);
		queue.add(20);
		queue.add(30);
		queue.add(40);
		queue.add(50);

		// Display the queue
		System.out.println("Queue elements: " + queue);

		// Remove elements from the queue
		System.out.println("\nDequeuing elements from the queue:");
		while (!queue.isEmpty()) {
			int removedElement = queue.poll();
			System.out.println("Dequeued element: " + removedElement);
		}

		// Check if the queue is empty after removal
		if (queue.isEmpty()) {
			System.out.println("\nThe queue is empty now.");
		} else {
			System.out.println("\nThe queue is not empty.");
		}
	}
}
