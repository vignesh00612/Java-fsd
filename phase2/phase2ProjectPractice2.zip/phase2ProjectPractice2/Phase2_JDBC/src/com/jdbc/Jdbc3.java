package com.jdbc;

import java.sql.*;

public class Jdbc3 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conObj = DriverManager.getConnection("jdbc:mysql://localhost:3306/abmsschool","root", "Vignesh@1999");
			Statement st = conObj.createStatement();
			ResultSet rs = st.executeQuery("select * from employee");
			while(rs.next()) {
				System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3));
			}
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}



}
