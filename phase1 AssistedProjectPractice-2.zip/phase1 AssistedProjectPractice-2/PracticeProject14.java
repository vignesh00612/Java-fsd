package phase1AssistedPractice;

import java.util.Scanner;

public class PracticeProject14 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		try {
			// Attempt to read an integer from user input
			System.out.print("Enter an integer: ");
			int num = Integer.parseInt(scanner.nextLine());

			// Print the square of the entered number
			System.out.println("Square of " + num + " is: " + (num * num));
		} catch (NumberFormatException e) {
			// Handle the case when the input is not a valid integer
			System.out.println("Error: Please enter a valid integer.");
		} finally {
			// Close the scanner to release resources
			scanner.close();
		}
	}

}
