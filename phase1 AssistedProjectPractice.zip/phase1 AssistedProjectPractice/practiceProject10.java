package phase1AssistedPractice;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class practiceProject10 {

	public static void main(String[] args) {

		// Define a regular expression pattern
		String regex = "a*b";

		// Compile the pattern into a regex pattern object
		Pattern pattern = Pattern.compile(regex);

		// Define a test string
		String testString = "aaaab";

		// Create a matcher object for the test string
		Matcher matcher = pattern.matcher(testString);

		// Check if the test string matches the pattern
		if (matcher.matches()) {
			System.out.println("Test string matches the pattern: " + regex);
		} else {
			System.out.println("Test string does not match the pattern: " + regex);
		}

		// Using regular expression to find matches
		String text = "The cat sat on the mat and the bat flew away.";
		String patternToFind = "[cb]at"; // Matches "cat" and "bat"
		Pattern patternFinder = Pattern.compile(patternToFind);
		Matcher matcherFinder = patternFinder.matcher(text);

		// Find matches and print them
		System.out.println("Matches found:");
		while (matcherFinder.find()) {
			System.out.println(matcherFinder.group());
		}
	}

}
