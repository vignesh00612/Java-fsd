package com.jdbc;

import java.sql.*;
public class Jdbc6 {

	private static final String URL = "jdbc:mysql://localhost:3306/abmsschool";
    private static final String USER = "root";
    private static final String PASSWORD = "Vignesh@1999";
    
	public static void main(String[] args) {
		insert();
		update();
		delete();
	}
	
	public static void insert() {
		try
		{
			Connection conObj = DriverManager.getConnection(URL,USER, PASSWORD);
			Statement st = conObj.createStatement();
			st.execute("insert into employee values (4,'Sugumar',12000)");
			System.out.println("Inserted Successfully...");
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}
	
	public static void update() {
		try
		{
			Connection conObj = DriverManager.getConnection(URL,USER, PASSWORD);
			Statement st = conObj.createStatement();
			st.execute("update employee set employee_name='Dheena' where employee_id=2");
			System.out.println("Updated Successfully...");
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}
	
	public static void delete() {
		try
		{
			Connection conObj = DriverManager.getConnection(URL,USER, PASSWORD);
			Statement st = conObj.createStatement();
			st.execute("delete from employee where employee_id=4");
			System.out.println("deleted Successfully...");
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}

}
