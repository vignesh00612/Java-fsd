package phase1AssistedPractice;

// Parent class
class Animal {
	private String name;

	// Constructor
	public Animal(String name) {
		this.name = name;
	}

	// Encapsulation: getter method
	public String getName() {
		return name;
	}

	// Abstraction: method to perform a generic action
	public void speak() {
		System.out.println("Animal speaks.");
	}
}

// Inheritance: Child class inherits from the parent class
class Dog extends Animal {
	// Constructor
	public Dog(String name) {
		super(name);
	}

	// Polymorphism: method overriding
	@Override
	public void speak() {
		System.out.println("Dog barks.");
	}
}

// Another child class inheriting from Animal
class Cat extends Animal {
	// Constructor
	public Cat(String name) {
		super(name);
	}

	// Polymorphism: method overriding
	@Override
	public void speak() {
		System.out.println("Cat meows.");
	}
}

public class PracticeProject18 {

	public static void main(String[] args) {
		// Create objects of different classes
		Animal animal = new Animal("Generic Animal");
		Dog dog = new Dog("Buddy");
		Cat cat = new Cat("Whiskers");

		// Accessing properties using getter method (encapsulation)
		System.out.println("Name of the animal: " + animal.getName());
		System.out.println("Name of the dog: " + dog.getName());
		System.out.println("Name of the cat: " + cat.getName());

		// Accessing methods (abstraction)
		animal.speak();
		dog.speak();
		cat.speak();

		// Polymorphism: Dynamic method dispatch
		Animal anotherDog = new Dog("Rex");
		anotherDog.speak(); // Will invoke Dog's speak() method

		Animal anotherCat = new Cat("Mittens");
		anotherCat.speak(); // Will invoke Cat's speak() method
	}
}
