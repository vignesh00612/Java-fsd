package phase1AssistedPractice;

import java.util.Scanner;

public class PracticeProject22 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		// Input the size of the array
		System.out.print("Enter the size of the array: ");
		int n = scanner.nextInt();

		int[] arr = new int[n];

		// Input the elements of the array
		System.out.println("Enter the elements of the array:");
		for (int i = 0; i < n; i++) {
			arr[i] = scanner.nextInt();
		}

		// Input the range
		System.out.print("Enter the value of L (0 <= L <= n-1): ");
		int L = scanner.nextInt();
		System.out.print("Enter the value of R (L <= R <= n-1): ");
		int R = scanner.nextInt();

		// Calculate the sum of elements in the range [L, R]
		int sum = calculateSumInRange(arr, L, R);

		// Output the result
		System.out.println("The sum of elements in the range [" + L + ", " + R + "] is: " + sum);
	}

	public static int calculateSumInRange(int[] arr, int L, int R) {
		int sum = 0;
		for (int i = L; i <= R; i++) {
			sum += arr[i];
		}
		return sum;
	}

}
