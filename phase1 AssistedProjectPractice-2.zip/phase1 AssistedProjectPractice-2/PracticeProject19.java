package phase1AssistedPractice;

//Interface A
interface A {
	default void print() {
		System.out.println("A");
	}
}

// Interface B extends A
interface B extends A {
	default void print() {
		System.out.println("B");
	}
}

// Interface C extends A
interface C extends A {
	default void print() {
		System.out.println("C");
	}
}

// Class D implements both B and C
class D implements B, C {
	// Resolving the diamond problem by overriding the conflicting default method
	@Override
	public void print() {
		B.super.print(); // Call the default method from interface B
		C.super.print(); // Call the default method from interface C
	}
}

public class PracticeProject19 {

	public static void main(String[] args) {
		D d = new D();
		d.print(); // Output: B C
	}

}
