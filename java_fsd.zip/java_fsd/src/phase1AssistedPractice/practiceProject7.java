package phase1AssistedPractice;

public class practiceProject7 {

	private int outerVar = 56;
	private static int staticOuterVar = 86;

	class InnerClass {
		void display() {
			System.out.println("Inner class method called.");
			System.out.println("Outer variable accessed from inner class: " + outerVar);
			System.out.println("Static outer variable accessed from inner class: " + staticOuterVar);
		}
	}

	public static void main(String[] args) {
		practiceProject7 outer = new practiceProject7();

		InnerClass inner = outer.new InnerClass();

		inner.display();
	}
}
